A Pen created at CodePen.io. You can find this one at http://codepen.io/Deemo/pen/cIdAk.

 Inspiration from David East  http://cssdeck.com/labs/flat-ui-login-form  