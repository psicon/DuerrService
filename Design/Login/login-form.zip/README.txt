A Pen created at CodePen.io. You can find this one at http://codepen.io/m412c0/pen/qahmr.

 Just a simple & flat login form :)